using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//This object is paired with the ActivatedMover.cs component

public class TriggerObject : MonoBehaviour
{
    [SerializeField] private GameObject objectToTrigger;
    [SerializeField] private LayerMask layerToCollide;

    private ActivatedMover theMover;

    private void Start()
    {
        theMover = objectToTrigger.GetComponent<ActivatedMover>();
    }

    private void OnTriggerEnter(Collider collision)
    {
        //int enemy1 = LayerMask.NameToLayer("Player");

        LayerMask theLayer = collision.gameObject.layer;
  
        //Stupid shit we have to do to see if the mask and the layer are the same
        if ((layerToCollide.value & (1 << theLayer.value)) != 0)
        {
            // yup
            Debug.Log("Mask found it");
            theMover.activate();
        }


    }

}
